<?php include 'partials/header.php'; if(!is_admin()){ http_response_code(403); exit('Forbidden'); }
$pending = fetch_all(q("SELECT m.*, u.name AS user_name, c.name AS club_name
  FROM memberships m JOIN users u ON m.user_id=u.id JOIN clubs c ON m.club_id=c.id
  WHERE m.status='pending' ORDER BY m.created_at ASC"));
$clubs = fetch_all(q("SELECT * FROM clubs ORDER BY name ASC"));
?>
<h3>Admin Dashboard</h3>

<h5 class="mt-4">Pending Membership Requests</h5>
<table class="table table-sm table-striped">
  <thead><tr><th>User</th><th>Club</th><th>Status</th><th>Role</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach($pending as $m): ?>
    <tr>
      <td><?=htmlspecialchars($m['user_name'])?> (ID <?=$m['user_id']?>)</td>
      <td><?=htmlspecialchars($m['club_name'])?></td>
      <td><?=$m['status']?></td>
      <td><?=$m['role_in_club']?></td>
      <td>
        <form method="post" action="admin_actions.php" class="d-inline">
          <input type="hidden" name="id" value="<?=$m['id']?>">
          <button class="btn btn-success btn-sm" name="action" value="approve">Approve</button>
        </form>
        <form method="post" action="admin_actions.php" class="d-inline">
          <input type="hidden" name="id" value="<?=$m['id']?>">
          <button class="btn btn-danger btn-sm" name="action" value="reject">Reject</button>
        </form>
        <form method="post" action="admin_actions.php" class="d-inline">
          <input type="hidden" name="id" value="<?=$m['id']?>">
          <button class="btn btn-warning btn-sm" name="action" value="promote">Promote to Officer</button>
        </form>
      </td>
    </tr>
  <?php endforeach; if(empty($pending)): ?>
    <tr><td colspan="5" class="text-muted">No pending requests.</td></tr>
  <?php endif; ?>
  </tbody>
</table>

<h5 class="mt-4">All Clubs</h5>
<ul>
  <?php foreach($clubs as $c): ?><li><a href="club_detail.php?id=<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></a></li><?php endforeach; ?>
</ul>
<?php include 'partials/footer.php'; ?>