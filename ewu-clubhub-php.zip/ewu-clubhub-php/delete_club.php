<?php require 'db.php'; if(!is_admin()) { http_response_code(403); exit; }
$id = (int)($_POST['id'] ?? 0);
if($id){ q("DELETE FROM clubs WHERE id=?",[$id]); }
header('Location: clubs.php'); exit;