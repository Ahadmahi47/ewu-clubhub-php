<?php include 'partials/header.php';
$club_id = (int)($_GET['club_id'] ?? 0);
$event_id = (int)($_GET['id'] ?? 0);
if(!$me){ require_login(); }
if(!is_admin() && !is_officer($me['id'], $club_id ? $club_id : (fetch_one(q("SELECT club_id FROM events WHERE id=?",[$event_id]))['club_id'] ?? 0))){
  http_response_code(403); exit('Forbidden');
}
$club = $club_id ? fetch_one(q("SELECT * FROM clubs WHERE id=?",[$club_id])) : null;
$event = ['title'=>'','description'=>'','venue'=>'','start_time'=>'','end_time'=>'','capacity'=>''];
if($event_id){ $event = fetch_one(q("SELECT * FROM events WHERE id=?",[$event_id])); $club_id = $event['club_id']; $club = fetch_one(q("SELECT * FROM clubs WHERE id=?",[$club_id])); }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title=$_POST['title']??''; $desc=$_POST['description']??''; $venue=$_POST['venue']??'';
  $start=$_POST['start_time']??null; $end=$_POST['end_time']??null; $cap=$_POST['capacity']!==''? (int)$_POST['capacity']: null;
  if($event_id){
    q("UPDATE events SET title=?, description=?, venue=?, start_time=?, end_time=?, capacity=? WHERE id=?",
      [$title,$desc,$venue,$start,$end,$cap,$event_id]);
  } else {
    q("INSERT INTO events(club_id, created_by, title, description, venue, start_time, end_time, capacity)
       VALUES (?,?,?,?,?,?,?,?)", [$club_id,$me['id'],$title,$desc,$venue,$start,$end,$cap]);
    $event_id = $mysqli->insert_id;
  }
  header('Location: event_detail.php?id='.$event_id); exit;
}
?>
<h3><?= $event_id? 'Update':'Create' ?> Event — <?=htmlspecialchars($club['name'] ?? '')?></h3>
<form method="post" class="col-md-10">
  <div class="mb-3">
    <label class="form-label">Title</label>
    <input class="form-control" name="title" required value="<?=htmlspecialchars($event['title'])?>">
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Start time</label>
      <input type="datetime-local" class="form-control" name="start_time"
        value="<?= $event['start_time'] ? date('Y-m-d\TH:i', strtotime($event['start_time'])) : '' ?>">
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">End time</label>
      <input type="datetime-local" class="form-control" name="end_time"
        value="<?= $event['end_time'] ? date('Y-m-d\TH:i', strtotime($event['end_time'])) : '' ?>">
    </div>
  </div>
  <div class="row">
    <div class="col-md-8 mb-3">
      <label class="form-label">Venue</label>
      <input class="form-control" name="venue" value="<?=htmlspecialchars($event['venue'])?>">
    </div>
    <div class="col-md-4 mb-3">
      <label class="form-label">Capacity</label>
      <input type="number" class="form-control" name="capacity" value="<?=htmlspecialchars($event['capacity'])?>">
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea class="form-control" name="description" rows="4"><?=htmlspecialchars($event['description'])?></textarea>
  </div>
  <button class="btn btn-success"><?= $event_id? 'Update':'Create' ?></button>
</form>
<?php include 'partials/footer.php'; ?>