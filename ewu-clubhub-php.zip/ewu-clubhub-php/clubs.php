<?php include 'partials/header.php';
$clubs = fetch_all(q("SELECT * FROM clubs ORDER BY name ASC"));
?>
<div class="d-flex justify-content-between align-items-center">
  <h3>All Clubs</h3>
  <?php if(is_admin()): ?><a class="btn btn-primary btn-sm" href="club_form.php">+ New Club</a><?php endif; ?>
</div>
<table class="table table-striped mt-3">
  <thead><tr><th>Name</th><th>Category</th><th>Room</th><th></th></tr></thead>
  <tbody>
  <?php foreach($clubs as $c): ?>
    <tr>
      <td><?=htmlspecialchars($c['name'])?> <?= $c['acronym']?'('.htmlspecialchars($c['acronym']).')':'' ?></td>
      <td><?=htmlspecialchars($c['category'])?></td>
      <td><?=htmlspecialchars($c['room_no'])?></td>
      <td class="text-end">
        <a class="btn btn-outline-secondary btn-sm" href="club_detail.php?id=<?=$c['id']?>">View</a>
        <?php if(is_admin()): ?>
          <a class="btn btn-outline-primary btn-sm" href="club_form.php?id=<?=$c['id']?>">Edit</a>
          <form method="post" action="delete_club.php" class="d-inline">
            <input type="hidden" name="id" value="<?=$c['id']?>">
            <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete club?')">Delete</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php include 'partials/footer.php'; ?>