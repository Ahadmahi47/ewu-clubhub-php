<?php require 'db.php';
$exists = fetch_one(q("SELECT id FROM users WHERE email='admin@ewu.edu'"));
if(!$exists){
  $hash = password_hash('admin123', PASSWORD_DEFAULT);
  q("INSERT INTO users(name,student_id,email,dept,password_hash,is_admin) VALUES
    ('System Admin','000000','admin@ewu.edu','Admin',?,1)",[$hash]);
}
if(!fetch_one(q("SELECT id FROM clubs LIMIT 1"))){
  q("INSERT INTO clubs(name,acronym,category,email,room_no,description) VALUES
    ('EWU Computer Programming Club','EWUCoPC','Technical','copc@ewu.edu','A-5XX','Programming contests and workshops'),
    ('EWU Debate Club','EWUDC','Debate & Public Speaking','debate@ewu.edu','B-3XX','Debate and public speaking'),
    ('EWU Business Club','EWUBC','Business & Entrepreneurship','business@ewu.edu','C-2XX','Case competitions and talks'),
    ('EWU Cultural Club','EWUCC','Arts & Culture','cultural@ewu.edu','Auditorium','Cultural events and performances')");
}
$admin = fetch_one(q("SELECT id FROM users WHERE email='admin@ewu.edu'"));
$copc = fetch_one(q("SELECT id FROM clubs WHERE acronym='EWUCoPC'"));
if($admin && $copc && !fetch_one(q("SELECT id FROM events WHERE title LIKE 'Intro to Competitive Programming%'"))){
  q("INSERT INTO events(club_id,created_by,title,description,venue,start_time,end_time,capacity)
     VALUES (?,?,?,?,?,NOW(),NOW(),80)", [$copc['id'],$admin['id'],'Intro to Competitive Programming',
      'Kickoff workshop for new members','Room A-501']);
}
echo "Seeding done. Admin: admin@ewu.edu / admin123";