<?php require 'db.php'; if(!is_admin()){ http_response_code(403); exit; }
$id = (int)($_POST['id'] ?? 0);
$action = $_POST['action'] ?? '';
if($id && in_array($action, ['approve','reject','promote'])){
  if($action==='approve'){
    q("UPDATE memberships SET status='approved', joined_on=CURDATE() WHERE id=?",[$id]);
  } elseif($action==='reject'){
    q("UPDATE memberships SET status='rejected' WHERE id=?",[$id]);
  } elseif($action==='promote'){
    q("UPDATE memberships SET role_in_club='officer', status='approved', joined_on=CURDATE() WHERE id=?",[$id]);
  }
}
header('Location: admin.php'); exit;