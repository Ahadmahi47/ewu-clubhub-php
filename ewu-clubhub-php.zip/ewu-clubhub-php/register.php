<?php include 'partials/header.php';
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['name'] ?? '');
  $student_id = trim($_POST['student_id'] ?? '');
  $dept = trim($_POST['dept'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  if(!$name || !$student_id || !$email || !$password){
    $msg='Please fill all required fields.';
  } else {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    try{
      q("INSERT INTO users(name,student_id,email,dept,password_hash) VALUES (?,?,?,?,?)",
        [$name,$student_id,$email,$dept,$hash]);
      $u_id = $mysqli->insert_id;
      $_SESSION['user_id']=$u_id; $_SESSION['is_admin']=0;
      header('Location: index.php'); exit;
    } catch(Exception $e){
      $msg='Email or Student ID already exists.';
    }
  }
}
?>
<h3>Create an account</h3>
<?php if($msg): ?><div class="alert alert-warning"><?=$msg?></div><?php endif; ?>
<form method="post" class="col-md-8">
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Full name</label>
      <input class="form-control" name="name" required>
    </div>
    <div class="col-md-3 mb-3">
      <label class="form-label">Student ID</label>
      <input class="form-control" name="student_id" required>
    </div>
    <div class="col-md-3 mb-3">
      <label class="form-label">Department</label>
      <input class="form-control" name="dept" placeholder="e.g., CSE, BBA">
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" class="form-control" name="email" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Password</label>
    <input type="password" class="form-control" name="password" required>
  </div>
  <button class="btn btn-success">Register</button>
</form>
<?php include 'partials/footer.php'; ?>