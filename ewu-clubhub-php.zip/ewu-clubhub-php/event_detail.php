<?php include 'partials/header.php';
$event_id = (int)($_GET['id'] ?? 0);
$event = fetch_one(q("SELECT e.*, c.name AS club_name FROM events e JOIN clubs c ON e.club_id=c.id WHERE e.id=?",[$event_id]));
if(!$event){ http_response_code(404); exit('Event not found'); }

$already = null;
if(!empty($_SESSION['user_id'])){
  $already = fetch_one(q("SELECT * FROM registrations WHERE event_id=? AND user_id=?",[$event_id,$_SESSION['user_id']]));
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['register']) && $me){
    // capacity check
    if(!empty($event['capacity'])){
      $count = fetch_one(q("SELECT COUNT(*) AS c FROM registrations WHERE event_id=? AND status='registered'",[$event_id]));
      if($count && $count['c'] >= (int)$event['capacity']){
        $msg="Event is full."; // fall through to view
      } else {
        q("INSERT INTO registrations(event_id,user_id,status) VALUES (?,?, 'registered')",[$event_id,$me['id']]);
        header('Location: event_detail.php?id='.$event_id); exit;
      }
    } else {
      q("INSERT INTO registrations(event_id,user_id,status) VALUES (?,?, 'registered')",[$event_id,$me['id']]);
      header('Location: event_detail.php?id='.$event_id); exit;
    }
  }
  if(isset($_POST['cancel']) && $me && $already){
    q("UPDATE registrations SET status='cancelled' WHERE id=?",[$already['id']]);
    header('Location: event_detail.php?id='.$event_id); exit;
  }
}
$attendees = fetch_all(q("SELECT * FROM registrations WHERE event_id=? AND status='registered'",[$event_id]));
?>
<div class="d-flex justify-content-between align-items-center">
  <h3><?=htmlspecialchars($event['title'])?></h3>
  <div>
    <?php if($me && (is_admin() || $me['id']==$event['created_by'] || is_officer($me['id'],$event['club_id']))): ?>
      <a class="btn btn-outline-primary btn-sm" href="event_form.php?id=<?=$event_id?>">Edit</a>
      <form method="post" action="delete_event.php" class="d-inline">
        <input type="hidden" name="id" value="<?=$event_id?>">
        <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete event?')">Delete</button>
      </form>
    <?php endif; ?>
  </div>
</div>
<p class="text-muted">Club: <a href="club_detail.php?id=<?=$event['club_id']?>"><?=htmlspecialchars($event['club_name'])?></a>
 | Venue: <?=htmlspecialchars($event['venue'] ?? 'TBA')?></p>
<p class="text-muted">Time: <?= $event['start_time'] ? date('M d, Y H:i', strtotime($event['start_time'])) : 'TBA' ?>
<?php if($event['end_time']) echo ' - '.date('H:i', strtotime($event['end_time'])); ?></p>
<p><?=nl2br(htmlspecialchars($event['description']))?></p>

<?php if($me): ?>
  <?php if($already && $already['status']=='registered'): ?>
    <form method="post"><button name="cancel" value="1" class="btn btn-warning btn-sm">Cancel Registration</button></form>
  <?php elseif($already && $already['status']=='cancelled'): ?>
    <p class="text-muted">You cancelled your registration.</p>
  <?php else: ?>
    <form method="post"><button name="register" value="1" class="btn btn-primary btn-sm">Register</button></form>
  <?php endif; ?>
<?php else: ?>
  <p><a href="login.php">Login</a> to register.</p>
<?php endif; ?>

<hr><h5>Registered Attendees</h5>
<ul>
  <?php foreach($attendees as $r): ?>
    <li>User ID <?=$r['user_id']?> (status: <?=$r['status']?>)</li>
  <?php endforeach; if(empty($attendees)): ?>
    <li class="text-muted">No registrations yet.</li>
  <?php endif; ?>
</ul>
<?php include 'partials/footer.php'; ?>