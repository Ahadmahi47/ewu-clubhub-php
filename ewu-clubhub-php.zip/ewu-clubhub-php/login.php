<?php include 'partials/header.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $stmt = q("SELECT * FROM users WHERE email=?", [$email]);
  $u = fetch_one($stmt);
  if($u && password_verify($password, $u['password_hash'])){
    $_SESSION['user_id']=$u['id']; $_SESSION['is_admin']=$u['is_admin'];
    header('Location: index.php'); exit;
  } else { $error='Invalid email or password.'; }
}
?>
<h3>Login</h3>
<?php if($error): ?><div class="alert alert-warning"><?=$error?></div><?php endif; ?>
<form method="post" class="col-md-6">
  <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" class="form-control" name="email" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Password</label>
    <input type="password" class="form-control" name="password" required>
  </div>
  <button class="btn btn-primary">Login</button>
</form>
<?php include 'partials/footer.php'; ?>