<?php include 'partials/header.php';
$clubs = fetch_all(q("SELECT * FROM clubs ORDER BY name ASC"));
$events = fetch_all(q("SELECT e.*, c.name AS club_name FROM events e JOIN clubs c ON e.club_id=c.id ORDER BY e.start_time ASC LIMIT 8"));
?>
<h3>Clubs at East West University</h3>
<div class="row row-cols-1 row-cols-md-2 g-3">
<?php foreach($clubs as $c): ?>
  <div class="col"><div class="card">
    <div class="card-body">
      <h5 class="card-title"><?=htmlspecialchars($c['name'])?> <?= $c['acronym']? '('.htmlspecialchars($c['acronym']).')':''?></h5>
      <p class="card-text"><?=htmlspecialchars(substr($c['description'] ?? '',0,160))?></p>
      <a class="btn btn-outline-primary btn-sm" href="club_detail.php?id=<?=$c['id']?>">View</a>
    </div>
  </div></div>
<?php endforeach; ?>
</div>

<hr class="my-4">
<h3>Upcoming Events</h3>
<div class="list-group">
<?php foreach($events as $e): ?>
  <a class="list-group-item list-group-item-action" href="event_detail.php?id=<?=$e['id']?>">
    <strong><?=htmlspecialchars($e['title'])?></strong> — <?=htmlspecialchars($e['venue'] ?? 'TBA')?> | 
    <?= $e['start_time'] ? date('M d, Y H:i', strtotime($e['start_time'])) : 'TBA' ?>
    <span class="text-muted"> | Club: <?=htmlspecialchars($e['club_name'])?></span>
  </a>
<?php endforeach; if(empty($events)): ?>
  <p class="text-muted">No upcoming events yet.</p>
<?php endif; ?>
</div>
<?php include 'partials/footer.php'; ?>