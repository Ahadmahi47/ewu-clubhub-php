<?php
include 'partials/header.php';
if (!is_admin()) { http_response_code(403); exit('Forbidden'); }

// Show PHP errors for this page (you can remove later)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$club = ['name'=>'','acronym'=>'','category'=>'','email'=>'','room_no'=>'','founded_on'=>'','description'=>''];

if ($id) {
  $stmt = q("SELECT * FROM clubs WHERE id=?", [$id]);
  $club = fetch_one($stmt);
  if (!$club) { die('Club not found'); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $acronym = trim($_POST['acronym'] ?? '');
  $category = trim($_POST['category'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $room_no = trim($_POST['room_no'] ?? '');
  $founded_on = $_POST['founded_on'] ?? ''; // may be ''
  $description = trim($_POST['description'] ?? '');

  if ($name === '') { die('Name is required'); }

  if ($id) {
    // Use NULLIF on the date so '' becomes NULL (avoids strict date errors)
    q("UPDATE clubs
         SET name=?, acronym=?, category=?, email=?, room_no=?, founded_on=NULLIF(?, ''), description=?
       WHERE id=?",
      [$name,$acronym,$category,$email,$room_no,$founded_on,$description,$id]);
  } else {
    q("INSERT INTO clubs (name,acronym,category,email,room_no,founded_on,description)
       VALUES (?,?,?,?,?,NULLIF(?, ''),?)",
      [$name,$acronym,$category,$email,$room_no,$founded_on,$description]);
    global $mysqli;
    $id = $mysqli->insert_id;
  }
  header('Location: club_detail.php?id='.$id);
  exit;
}
?>
<h3><?= $id ? 'Update' : 'Create' ?> Club</h3>
<form method="post" class="col-md-10">
  <div class="row">
    <div class="col-md-8 mb-3">
      <label class="form-label">Name</label>
      <input class="form-control" name="name" required value="<?=htmlspecialchars($club['name'])?>">
    </div>
    <div class="col-md-4 mb-3">
      <label class="form-label">Acronym</label>
      <input class="form-control" name="acronym" value="<?=htmlspecialchars($club['acronym'])?>">
    </div>
  </div>
  <div class="row">
    <div class="col-md-4 mb-3">
      <label class="form-label">Category</label>
      <input class="form-control" name="category" value="<?=htmlspecialchars($club['category'])?>">
    </div>
    <div class="col-md-4 mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" name="email" value="<?=htmlspecialchars($club['email'])?>">
    </div>
    <div class="col-md-4 mb-3">
      <label class="form-label">Room No</label>
      <input class="form-control" name="room_no" value="<?=htmlspecialchars($club['room_no'])?>">
    </div>
  </div>
  <div class="row">
    <div class="col-md-4 mb-3">
      <label class="form-label">Founded On</label>
      <input type="date" class="form-control" name="founded_on" value="<?=htmlspecialchars($club['founded_on'])?>">
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea class="form-control" name="description" rows="4"><?=htmlspecialchars($club['description'])?></textarea>
  </div>
  <button class="btn btn-success"><?= $id ? 'Update' : 'Create' ?></button>
</form>
<?php include 'partials/footer.php'; ?>