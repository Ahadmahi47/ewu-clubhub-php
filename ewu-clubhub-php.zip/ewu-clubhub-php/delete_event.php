<?php require 'db.php'; require_login();
$event_id = (int)($_POST['id'] ?? 0);
$ev = fetch_one(q("SELECT * FROM events WHERE id=?",[$event_id]));
if(!$ev){ header('Location: index.php'); exit; }
if(!is_admin() && !is_officer($_SESSION['user_id'],$ev['club_id'])){ http_response_code(403); exit; }
q("DELETE FROM events WHERE id=?",[$event_id]);
header('Location: club_detail.php?id='.$ev['club_id']); exit;