<?php
// Adjust DB_PORT to your MySQL port (3306 default; 3307 if you changed it)
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'ewu_clubhub';
$DB_PORT = 3306;

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
if ($mysqli->connect_errno) {
    die('MySQL connection failed ('.$mysqli->connect_errno.'): '.$mysqli->connect_error);
}
$mysqli->set_charset('utf8mb4');
session_start();

/*
  q() always uses prepared statements and returns mysqli_stmt.
  We never use get_result(), so this works even without mysqlnd.
*/
function q($sql, $params = [], $types = '') {
    global $mysqli;
    $stmt = $mysqli->prepare($sql);
    if (!$stmt) die('Prepare failed: '.$mysqli->error.' | SQL: '.$sql);

    if (!empty($params)) {
        if ($types === '') {
            foreach ($params as $p) {
                $types .= is_int($p) ? 'i' : (is_float($p) ? 'd' : 's');
            }
        }
        $stmt->bind_param($types, ...$params);
    }
    if (!$stmt->execute()) {
        die('Execute failed: '.$stmt->error.' | SQL: '.$sql);
    }
    return $stmt; // always a stmt
}

// Fetch helpers that do not use get_result()
function stmt_fetch_all_assoc(mysqli_stmt $stmt): array {
    $stmt->store_result();
    $meta = $stmt->result_metadata();
    if (!$meta) return [];
    $fields = $meta->fetch_fields();
    $row = [];
    $bindRefs = [];
    foreach ($fields as $f) {
        $row[$f->name] = null;
        $bindRefs[] = &$row[$f->name];
    }
    call_user_func_array([$stmt, 'bind_result'], $bindRefs);
    $out = [];
    while ($stmt->fetch()) {
        // make a copy to detach references
        $out[] = array_map(fn($v) => $v, $row);
    }
    return $out;
}

function fetch_all($resOrStmt): array {
    if ($resOrStmt instanceof mysqli_stmt) {
        return stmt_fetch_all_assoc($resOrStmt);
    }
    if ($resOrStmt instanceof mysqli_result) {
        // In case something passes a mysqli_result, handle it too
        $rows = [];
        while ($r = $resOrStmt->fetch_assoc()) { $rows[] = $r; }
        return $rows;
    }
    return [];
}

function fetch_one($resOrStmt) {
    $rows = fetch_all($resOrStmt);
    return $rows[0] ?? null;
}

// Auth helpers
function current_user() {
    if (!empty($_SESSION['user_id'])) {
        $stmt = q("SELECT id, name, email, is_admin FROM users WHERE id=?", [$_SESSION['user_id']]);
        $row = fetch_one($stmt);
        return $row ?: null;
    }
    return null;
}
function require_login() {
    if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }
}
function is_admin() { return !empty($_SESSION['is_admin']); }
function is_officer($user_id, $club_id) {
    $stmt = q("SELECT role_in_club FROM memberships
               WHERE user_id=? AND club_id=? AND status='approved' LIMIT 1",
               [$user_id, $club_id]);
    $row = fetch_one($stmt);
    return $row && in_array($row['role_in_club'], ['officer','president'], true);
}