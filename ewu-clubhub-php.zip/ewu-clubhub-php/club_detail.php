<?php include 'partials/header.php';
$club_id = (int)($_GET['id'] ?? 0);
$club = fetch_one(q("SELECT * FROM clubs WHERE id=?",[$club_id]));
if(!$club){ http_response_code(404); exit('Club not found'); }
$events = fetch_all(q("SELECT * FROM events WHERE club_id=? ORDER BY start_time DESC",[$club_id]));
$membership = null;
if(!empty($_SESSION['user_id'])){
  $membership = fetch_one(q("SELECT * FROM memberships WHERE user_id=? AND club_id=?",
    [$_SESSION['user_id'],$club_id]));
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['join']) && !empty($_SESSION['user_id'])){
  if(!$membership){
    q("INSERT INTO memberships(user_id, club_id, status) VALUES (?,?, 'pending')",
      [$_SESSION['user_id'],$club_id]);
    header("Location: club_detail.php?id=$club_id"); exit;
  }
}
?>
<div class="d-flex justify-content-between align-items-center">
  <h3><?=htmlspecialchars($club['name'])?> <?= $club['acronym']?'('.htmlspecialchars($club['acronym']).')':'' ?></h3>
  <?php if($me && (is_admin() || is_officer($me['id'],$club_id))): ?>
    <a class="btn btn-primary btn-sm" href="event_form.php?club_id=<?=$club_id?>">+ New Event</a>
  <?php endif; ?>
</div>
<p class="text-muted">Category: <?=htmlspecialchars($club['category'])?> | Room: <?=htmlspecialchars($club['room_no'])?> | Email: <?=htmlspecialchars($club['email'])?></p>
<p><?=nl2br(htmlspecialchars($club['description']))?></p>

<?php if($me): ?>
  <?php if(!$membership): ?>
    <form method="post"><button class="btn btn-outline-primary btn-sm" name="join" value="1">Request Membership</button></form>
  <?php else: ?>
    <p class="badge bg-info">Your membership status: <?=$membership['status']?> (role: <?=$membership['role_in_club']?>)</p>
  <?php endif; ?>
<?php else: ?>
  <p><a href="login.php">Login</a> to request membership.</p>
<?php endif; ?>

<hr><h5>Events</h5>
<div class="list-group">
  <?php foreach($events as $e): ?>
    <a class="list-group-item" href="event_detail.php?id=<?=$e['id']?>">
      <strong><?=htmlspecialchars($e['title'])?></strong> — <?=htmlspecialchars($e['venue'] ?? 'TBA')?> |
      <?= $e['start_time'] ? date('M d, Y H:i', strtotime($e['start_time'])) : 'TBA' ?>
    </a>
  <?php endforeach; if(empty($events)): ?>
    <p class="text-muted">No events yet.</p>
  <?php endif; ?>
</div>
<?php include 'partials/footer.php'; ?>