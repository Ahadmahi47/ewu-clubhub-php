-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2025 at 02:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ewu_clubhub`
--

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `id` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `acronym` varchar(40) DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `room_no` varchar(40) DEFAULT NULL,
  `founded_on` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` (`id`, `name`, `acronym`, `category`, `email`, `room_no`, `founded_on`, `description`, `created_at`) VALUES
(1, 'EWU Computer Programming Club', 'EWUCoPC', 'Technical', 'copc@ewu.edu', 'A-5XX', NULL, 'Programming contests and workshops', '2025-08-31 22:55:17'),
(2, 'EWU Debate Club', 'EWUDC', 'Debate & Public Speaking', 'debate@ewu.edu', 'B-3XX', NULL, 'Debate and public speaking', '2025-08-31 22:55:17'),
(3, 'EWU Business Club', 'EWUBC', 'Business & Entrepreneurship', 'business@ewu.edu', 'C-2XX', NULL, 'Case competitions and talks', '2025-08-31 22:55:17'),
(4, 'EWU Cultural Club', 'EWUCC', 'Arts & Culture', 'cultural@ewu.edu', 'Auditorium', NULL, 'Cultural events and performances', '2025-08-31 22:55:17');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `title` varchar(160) NOT NULL,
  `description` text DEFAULT NULL,
  `venue` varchar(120) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `club_id`, `created_by`, `title`, `description`, `venue`, `start_time`, `end_time`, `capacity`, `created_at`) VALUES
(1, 1, 1, 'Intro to Competitive Programming', 'Kickoff workshop for new members', 'Room A-501', '2025-08-31 22:55:17', '2025-08-31 22:55:17', 80, '2025-08-31 22:55:17');

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `role_in_club` enum('member','officer','president') DEFAULT 'member',
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `joined_on` date DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`id`, `user_id`, `club_id`, `role_in_club`, `status`, `joined_on`, `created_at`) VALUES
(2, 1, 3, 'member', 'rejected', NULL, '2025-08-31 23:08:06'),
(3, 3, 1, 'officer', 'approved', '2025-08-31', '2025-08-31 23:13:02'),
(4, 3, 4, 'member', 'rejected', NULL, '2025-09-02 00:32:37');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('registered','cancelled','attended') DEFAULT 'registered',
  `registered_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `event_id`, `user_id`, `status`, `registered_on`) VALUES
(1, 1, 3, 'registered', '2025-09-02 00:37:19'),
(2, 1, 1, 'cancelled', '2025-09-02 00:38:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `student_id` varchar(32) NOT NULL,
  `email` varchar(120) NOT NULL,
  `dept` varchar(64) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `student_id`, `email`, `dept`, `password_hash`, `is_admin`, `created_at`) VALUES
(1, 'System Admin', '000000', 'admin@ewu.edu', 'Admin', '$2y$10$54iRZDTLMmNxaLjrLlx6J.9.WzSBaR78Z8YfJI/Izt22yWGX37Ify', 1, '2025-08-31 22:55:17'),
(3, 'Ahad Mahi', '2023-2-60-157', '2023-2-60-157@std.ewubd.edu', 'CSE', '$2y$10$ZtZiUqvT0hU4NITmEB1SD.lkIjhql.KWAAU7jCDKrMoRCENDuxG8W', 0, '2025-08-31 23:12:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_e_club` (`club_id`),
  ADD KEY `fk_e_user` (`created_by`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_user_club` (`user_id`,`club_id`),
  ADD KEY `fk_m_club` (`club_id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_event_user` (`event_id`,`user_id`),
  ADD KEY `fk_r_user` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clubs`
--
ALTER TABLE `clubs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `fk_e_club` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_e_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `memberships`
--
ALTER TABLE `memberships`
  ADD CONSTRAINT `fk_m_club` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_m_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `fk_r_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_r_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
